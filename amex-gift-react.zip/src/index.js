import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import GiftCard from './GiftCard';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <GiftCard />
  </React.StrictMode>
);